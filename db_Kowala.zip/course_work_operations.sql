USE kowala;



-- Задание 1. 	найти и вывести на экран наименование продукции и ее количество  произведенной из пленки с id 7 которая была принята 
-- C 2000 года и на каких она складах


SELECT 
	p.name_of_product ,
	w.name, 
	m.created_at , 
	m.quantity 
FROM main m 
JOIN foils f ON f.id = m.foil_id
JOIN products p on p.id  = m.product_id 
JOIN warehouses w ON w.id = m.warehouse_id 
WHERE f.id = 7 AND m.created_at BETWEEN '2000-01-01' AND NOW();

-- Задание 2. найти какие виды товаров производим из определенной пленки

SELECT 
	foil_id,
	GROUP_CONCAT(name_of_product SEPARATOR ', ') AS product
FROM 
	(SELECT
		m.foil_id,
		p.name_of_product  
	FROM main m  
	JOIN products p ON m.product_id  = p.id
	RIGHT JOIN foils f ON f.id = m.foil_id) AS tab1
GROUP BY foil_id;


-- Задание 3. Найти, сколько осталось вторичного сырья с id 5 с разбивкой по складам

SELECT 
	w.name,
	em.description, 
	SUM(m.quantity) AS quantity  
FROM main m 
JOIN exp_materials em ON em.id =m.exp_material_id
JOIN warehouses w ON m.warehouse_id = w.id
WHERE em.id = 5
GROUP BY w.name ; 

-- заполним недостающие данные по поставщикам

UPDATE main 	
SET shipper =
	CASE 
		WHEN foil_id BETWEEN 1 AND 20  
			THEN 'FORTY'
		WHEN foil_id BETWEEN 21 AND 55  
			THEN 'POLIFOLIA'
		WHEN foil_id BETWEEN 56 AND 100  
			THEN 'STELLAPACK'
	END;	

-- Задание 4. создам представление, которое показывает остатки материалов и товаров на складе производства

DROP VIEW IF EXISTS production_statement;
CREATE VIEW production_statement AS 
SELECT 
	p.name_of_product,
	m2.name, 
	m.quantity 
FROM main m 
JOIN products p on p.id  = m.product_id
JOIN materials m2 ON m.material_id = m2.id  
JOIN warehouses w ON w.id = m.warehouse_id 
WHERE w.name = 'PRODUKCJA';


-- Задание 5. создам представление, которое показывает позиции, которых нет на складах, либо их очень мало

ALTER TABLE materials
RENAME COLUMN name TO material_name;


DROP VIEW IF EXISTS small_quantity;
CREATE VIEW small_quantity AS 
SELECT 
	w.name,
	p.name_of_product,
	m2.material_name, 
	m.foil_id,
	m.quantity 
FROM main m 
JOIN products p ON p.id  = m.product_id
JOIN materials m2 ON m.material_id = m2.id  
JOIN warehouses w ON w.id = m.warehouse_id
WHERE m.quantity < 500
ORDER BY m.quantity ;

-- Задание 6. создам триггер, который после обновления будет показывать после обновления, что позиции мало на складе

DROP TRIGGER IF EXISTS very_small_quantity;
DELIMITER //
CREATE TRIGGER very_small_quantity
AFTER UPDATE ON main FOR EACH ROW
BEGIN 
	IF NEW.quantity BETWEEN 0 AND 500 THEN 
		SIGNAL SQLSTATE '45000' 
		SET MESSAGE_TEXT = 'обратите внимание: на складе очень мало product_id';
	END IF;
END;//
DELIMITER ;

-- Задание 7. Создать процедуру производства матерала в пленку, где задается пленка и требуемое количество,
-- а берется 120% материала от количества пленки, и на выходе еще 20% вторсырья получается

DROP PROCEDURE IF EXISTS production;
DELIMITER //
CREATE PROCEDURE production (foil_id INT, quantity INT)
BEGIN 
	-- DECLARE mat_id INT;
		-- 	quantity_start DOUBLE;
	SET @mat_id = (SELECT m.id FROM foils f JOIN materials m ON m.kind_id = f.kind_id JOIN recipes r ON r.id  = f.recipe_id 
					WHERE m.colour_id = f.colour_id AND f.id  = foil_id ORDER BY f.id LIMIT 1);
	SET	@quantity_start = (SELECT m.quantity FROM main m WHERE m.material_id = @mat_id ORDER BY m.quantity DESC LIMIT 1);
	BEGIN
		UPDATE main m SET m.quantity = m.quantity - (1,2 * quantity), m.updated_at = NOW() WHERE m.material_id = @mat_id 
		AND m.quantity = @quantity_start;
		INSERT INTO main (warehouse_id, foil_id, quantity, created_at, updated_at) VALUES (6, foil_id , quantity, NOW(), NOW());
		INSERT INTO main (warehouse_id, secon_mat_id, quantity, created_at, updated_at) VALUES (6, @mat_id, quantity*0,2, NOW(), NOW());
	END;
END;//
DELIMITER ;


CALL production(16, 500);

-- проверки отдельно ddl комманды
UPDATE main m SET m.quantity = m.quantity - (1,2 * m.quantity), m.updated_at = NOW()  WHERE m.material_id = 2
		AND m.quantity IN (SELECT m.quantity FROM main m WHERE m.material_id = 2 ORDER BY m.quantity DESC LIMIT 1);

