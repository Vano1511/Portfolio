DROP DATABASE IF EXISTS kowala;
CREATE DATABASE kowala;
USE kowala;


DROP TABLE IF EXISTS kinds; -- справочник по видам материалов
CREATE TABLE kinds(
	id SERIAL PRIMARY KEY,
	kind VARCHAR(100) UNIQUE
	);

DROP TABLE IF EXISTS colours; -- справочник по цветам
CREATE TABLE colours(
	id SERIAL PRIMARY KEY,
	colour VARCHAR(100) UNIQUE
	);

DROP TABLE IF EXISTS recipes; -- справочник по рецептурам
CREATE TABLE recipes(
	id SERIAL,
	recipe_code VARCHAR(100) UNIQUE,
	definition VARCHAR (255),
	kind_id BIGINT UNSIGNED NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (kind_id) REFERENCES kinds(id) ON DELETE CASCADE ON UPDATE CASCADE
	);

DROP TABLE IF EXISTS materials;  -- справочник по сырью
CREATE TABLE materials(
	id SERIAL,
	kind_id BIGINT UNSIGNED NOT NULL,
	colour_id BIGINT UNSIGNED NOT NULL,
	name VARCHAR(100),
	PRIMARY KEY (id),
	FOREIGN KEY (kind_id) REFERENCES kinds(id) ON DELETE CASCADE ON UPDATE CASCADE,	
	FOREIGN KEY (colour_id) REFERENCES colours(id) ON DELETE CASCADE ON UPDATE CASCADE
	);

DROP TABLE IF EXISTS foils;  -- справочник по пленкам (промежуточный продукт)
CREATE TABLE foils(
	id SERIAL,
	kind_id BIGINT UNSIGNED NOT NULL,
	colour_id BIGINT UNSIGNED NOT NULL,
	recipe_id BIGINT UNSIGNED NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (kind_id) REFERENCES kinds(id) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (colour_id) REFERENCES colours(id) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE ON UPDATE CASCADE
	);


DROP TABLE IF EXISTS secondary_mat;  -- справочник переработанным отходам (вторсырье)
CREATE TABLE secondary_mat(
	id SERIAL,
	kind_id BIGINT UNSIGNED NOT NULL,
	colour_id BIGINT UNSIGNED NOT NULL,
	recipe_id BIGINT UNSIGNED NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (kind_id) REFERENCES kinds(id) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (colour_id) REFERENCES colours(id) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE ON UPDATE CASCADE
	);

DROP TABLE IF EXISTS products;  -- справочник по конечным продуктам
CREATE TABLE products(
	id SERIAL,
	name_of_product VARCHAR(200) UNIQUE,
	kind_id BIGINT UNSIGNED NOT NULL,
	colour_id BIGINT UNSIGNED NOT NULL,
	recipe_id BIGINT UNSIGNED NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (kind_id) REFERENCES kinds(id) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (colour_id) REFERENCES colours(id) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE ON UPDATE CASCADE,
	INDEX product_idx(name_of_product)
	);
	
DROP TABLE IF EXISTS exp_mat_groups;  -- справочник по группам расходных материалов
CREATE TABLE exp_mat_groups(
	id SERIAL PRIMARY KEY,
	name_of_group VARCHAR(100) UNIQUE
	);

DROP TABLE IF EXISTS exp_materials;  -- справочник самих расходных материалов
CREATE TABLE exp_materials(
	id SERIAL,
	group_id BIGINT UNSIGNED NOT NULL,
	material_id BIGINT UNSIGNED NOT NULL,
	description VARCHAR(100) UNIQUE,
	PRIMARY KEY (id),
	FOREIGN KEY (group_id) REFERENCES exp_mat_groups(id) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE CASCADE ON UPDATE CASCADE
	);

DROP TABLE IF EXISTS warehouses;  -- справочник по группам расходных материалов
CREATE TABLE warehouses(
	id SERIAL PRIMARY KEY,
	name VARCHAR(100) UNIQUE
	);

DROP TABLE IF EXISTS main;  -- главная таблица
CREATE TABLE main(
	id SERIAL,
	warehouse_id BIGINT UNSIGNED NOT NULL,
	foil_id BIGINT UNSIGNED,
	material_id BIGINT UNSIGNED,
	secon_mat_id BIGINT UNSIGNED,
	product_id BIGINT UNSIGNED,
	exp_material_id BIGINT UNSIGNED,
	quantity DOUBLE,
	created_at DATETIME NOT NULL,
	updated_at DATETIME NOT NULL,
	shipper VARCHAR(100),
	PRIMARY KEY (id),
	FOREIGN KEY (warehouse_id) REFERENCES warehouses(id)ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (secon_mat_id) REFERENCES secondary_mat(id),
	FOREIGN KEY (foil_id) REFERENCES foils(id),
	FOREIGN KEY (material_id) REFERENCES materials(id),
	FOREIGN KEY (product_id) REFERENCES products(id),
	FOREIGN KEY (exp_material_id) REFERENCES exp_materials(id),
	INDEX warehouse_idx(warehouse_id)
	);
	

	

