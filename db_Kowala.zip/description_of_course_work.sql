
Opis projektu kursu:

Ogólnie rzecz biorąc, firma kupuje surowce tworzyw sztucznych. Następnie za pomocą ekstrudera (mieszając surowce) produkuje folię o różnych rozmiarach i kolorach.
Część folii jest sprzedawana, część zabierana na własne potrzeby. Firma, z folii wykorzystujących termoformowanie, produkują tworzywa sztuczne
produkty (kubki, miski, pojemniki na produkty zamknięte itp.). Oczywiście bez odpadów nigdzie, ale folia odpadowa jest mielona
poddawane recyklingowi i dodawane przy produkcji folii podczas ekstruzji, w efekcie – produkcja bezodpadowa.
Dlatego stworzyłem tak wiele tabel referencyjnych, aby opisać wszystkie możliwe cechy. Następnie wszystko to zebrało się w głównej tablicy.
plus dodatkowo materiały pomocnicze: palety, folia stretch, taśma klejąca, kartony itp. Myślę, aby tworzyć
kolejna tabliczka (produkcja) do opisania samego procesu produkcyjnego (ile surowców i materiałów jest pobieranych do produkcji jednostki
produkt (zamówienie) i ile z tego wychodzi gotowy produkt (reszta jest poddawana recyklingowi).
